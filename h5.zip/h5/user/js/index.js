$(function(){
    // GetConfigFun();
});
